<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Student extends Model
{
    use HasFactory;

    // Specify the table name explicitly
    protected $table = 'student_admissions';
    // Define the relationship with Attendance model (since attendance has a foreign key 'student_id')
    public function attendances()
    {
        return $this->hasMany(Attendance::class, 'student_id', 'id');
        // 'student_id' in the Attendance table is related to 'id' in the Student table
    }
}
