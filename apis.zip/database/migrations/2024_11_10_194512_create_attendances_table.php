<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('attendances', function (Blueprint $table) {
            $table->id(); // Auto-incrementing ID for the attendance record
            $table->foreignId('student_id') // Foreign key linking to the student_admissions table
                ->constrained('student_admissions') // References the 'student_admissions' table instead of 'students'
                ->onDelete('cascade'); // If the related student is deleted, their attendance will also be deleted
            $table->date('date'); // Date of the attendance
            $table->enum('status', ['present', 'absent']); // Status, either 'present' or 'absent'
            $table->timestamps(); // Created_at and updated_at columns
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('attendances');
    }
};
